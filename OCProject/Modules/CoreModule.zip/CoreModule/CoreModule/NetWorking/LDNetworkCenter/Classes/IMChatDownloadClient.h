//
//  IMChatAttachmentDownload.h
//  laoyuegou
//
//  Created by Xiangqi on 16/9/18.
//  Copyright © 2016年 HaiNanLexin. All rights reserved.
//

#import "ChessHTTPClient.h"

@interface IMChatDownloadClient : ChessHTTPClient

@end
