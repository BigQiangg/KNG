//
//  NSArray+PlutoHTTPClient.h
//  laoyuegou
//
//  Created by Xiangqi on 2017/4/21.
//  Copyright © 2017年 HaiNanLexin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (PlutoHTTPClient)

- (NSString *)generatePlutoHTTPClientHashSignature;

@end
