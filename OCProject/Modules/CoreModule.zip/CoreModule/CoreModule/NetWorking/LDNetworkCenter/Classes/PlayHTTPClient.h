//
//  PlayHTTPClient.h
//  laoyuegou
//
//  Created by smalljun on 17/8/30.
//  Copyright © 2017年 HaiNanLexin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PlutoHTTPClient.h"

/**
 主要集中处理陪玩相关的接口
 */
@interface PlayHTTPClient : PlutoHTTPClient


@end
