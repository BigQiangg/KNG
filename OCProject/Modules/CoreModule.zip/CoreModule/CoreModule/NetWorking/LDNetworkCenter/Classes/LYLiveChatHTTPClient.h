//
//  LYLiveChatHTTPClient.h
//  laoyuegou
//
//  Created by Dombo on 2018/4/2.
//  Copyright © 2018年 HaiNanLexin. All rights reserved.
//

#import "PlutoHTTPClient.h"

@interface LYLiveChatHTTPClient : PlutoHTTPClient

+ (instancetype) shareInstance;
@end
