//
//  LYRecordDownloadClient.h
//  laoyuegou
//
//  Created by Jinxiansen on 2017/11/17.
//  Copyright © 2017年 HaiNanLexin. All rights reserved.
//

#import "ChessHTTPClient.h"

@interface LYRecordDownloadClient : ChessHTTPClient

@end
