//
//  LYWalletHTTPClient.h
//  laoyuegou
//
//  Created by hedgehog on 2018/1/8.
//  Copyright © 2018年 HaiNanLexin. All rights reserved.
//

#import "PlutoHTTPClient.h"

@interface LYWalletHTTPClient : PlutoHTTPClient

@end
