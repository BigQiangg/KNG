//
//  AFCustomResponseSerializer.h
//  laoyuegou
//
//  Created by Xiangqi on 16/9/18.
//  Copyright © 2016年 HaiNanLexin. All rights reserved.
//

#import "AFURLResponseSerialization.h"

@interface AFCustomResponseSerializer : AFHTTPResponseSerializer

@end
